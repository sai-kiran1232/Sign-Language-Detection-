# Real-Time-Sign-Language-Detection-Using-Deep-Learning
This is a model which detects sign language and translate to text/voice which benefits deaf community
